const PaymentRauter = require("express").Router()
const PaymentController = require("../controllers/payment")



module.exports = PaymentRauter