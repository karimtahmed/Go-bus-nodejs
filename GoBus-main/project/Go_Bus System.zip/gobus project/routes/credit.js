const CreditRouter = require("express").Router()
const CreditController = require("../controllers/credit")



module.exports = CreditRouter