const BusRouter = require("express").Router()

const BusController = require("../controllers/bus")


module.exports = BusRouter

