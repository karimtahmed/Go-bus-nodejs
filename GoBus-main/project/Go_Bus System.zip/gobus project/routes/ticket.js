const TicketRouter= require("express").Router()
const TicketConroller = require("../controllers/ticket")




module.exports= TicketRouter