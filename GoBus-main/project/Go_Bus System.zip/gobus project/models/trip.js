

class trip {
constructor(id,Code,DepTime,ArTime,bus_id,From,To){
this.id=id
this.Code=Code
this.DepTime=DepTime
this.ArTime=ArTime
this.bus_id=bus_id
this.From=From
this.To=To

}


}
module.exports=trip
