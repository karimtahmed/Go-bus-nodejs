class payment{
    constructor(id,PaymentType,Code){
    this.id=id
    this.PaymentType=PaymentType
    this.Code=Code

    }




}
module.exports=payment