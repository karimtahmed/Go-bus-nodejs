class bus {
    constructor(id, Code, BusClass, BookedSeats, AvailSeats) {
        this.id = id
        this.Code = Code
        this.BusClass = BusClass
        this.BookedSeats = BookedSeats
        this.AvailSeats = AvailSeats
    }
}

module.exports = bus