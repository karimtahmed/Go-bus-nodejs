class ticket{
constructor(passenger_id,creditcard_id,trip_id,trip_bus_id,Code,SeatNumber)
{
    
    this.passenger_id=passenger_id
    this.creditcard_id=creditcard_id
    this.trip_id=trip_id
    this.trip_bus_id=trip_bus_id
    this.Code=Code
    this.SeatNumber=SeatNumber

}




}
module.exports=ticket